# Physical Chemistry Learning Helper @ CPU - Pages

## [**简体中文**](./README.md) | **English**

The `Pages` page of the CPU Physical Chemistry Learning Helper, which is used for static page hosting services.

- Project source code: [https://github.com/roxszi/phys-chem-dev](https://github.com/roxszi/phys-chem-dev)

  Project source code (specifically for China mainland): [https://gitcode.com/roxszi/phys-chem-dev](https://gitcode.com/roxszi/phys-chem-dev)

- Project showcase page: [https://roxszi.github.io/phys-chem/en/](https://roxszi.github.io/phys-chem/en/)

  Project showcase page (specifically for China mainland): [https://cpuer.atomgit.net/phys-chem/](https://cpuer.atomgit.net/phys-chem/)
