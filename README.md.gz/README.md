# CPU物化助手-Pages

## **简体中文** | [**English**](./README.en.md)

CPU物化助手的Pages页面，用于静态页面托管服务。

- 项目源码：[https://gitcode.com/roxszi/phys-chem-dev](https://gitcode.com/roxszi/phys-chem-dev)

  项目源码（国外访问）：[https://github.com/roxszi/phys-chem-dev](https://github.com/roxszi/phys-chem-dev)

- 项目展示页面：[https://cpuer.atomgit.net/phys-chem](https://cpuer.atomgit.net/phys-chem)

  项目展示页面（国外访问）：[https://roxszi.github.io/phys-chem/en/](https://roxszi.github.io/phys-chem/en/)
